/* eslint-disable no-var */

declare global {
  interface Window {
    jQuery: any;
    $: any;
  }
}
export {};
