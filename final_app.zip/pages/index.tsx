import Head from "next/head";
import Image from "next/image";
import styles from "../styles/Home.module.css";
import { Slide } from "react-awesome-reveal";
import ContainerCom from "../components/container";
import Typewriter from "typewriter-effect";
import NavLink from "../components/NavLink";
// import BuildingsFinal from '../public/buildingsfinal.svg';
import Lottie from "lottie-react";
import CodingLot from "../public/coding.json";
import { Player, Controls } from "@lottiefiles/react-lottie-player";
// export default function Home() {
const Home = () => {
  return (
    <>
      <Head>
        <title>ראשי - DGW</title>
        <meta name="title" content="ראשי - DGW" />
        <meta
          name="description"
          content="DGW – דיגיטל וויב הינה חברה המתמחה בעיצוב ופיתוח אתרי אינטרנט ומערכות אינטרנט משולבות. ל- DGW יש יותר מ-15 שנות ניסיון במתן שירותי תכנות מקצועיים."
        />

        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://dgw.co.il/" />
        <meta property="og:title" content="ראשי - DGW" />
        <meta
          property="og:description"
          content="DGW – דיגיטל וויב הינה חברה המתמחה בעיצוב ופיתוח אתרי אינטרנט ומערכות אינטרנט משולבות. ל- DGW יש יותר מ-15 שנות ניסיון במתן שירותי תכנות מקצועיים."
        />
        <meta
          property="og:image"
          content="https://dgw.co.il/_next/image?url=%2Flogo3.png&w=256&q=75"
        />

        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content="https://dgw.co.il/" />
        <meta property="twitter:title" content="ראשי - DGW" />
        <meta
          property="twitter:description"
          content="DGW – דיגיטל וויב הינה חברה המתמחה בעיצוב ופיתוח אתרי אינטרנט ומערכות אינטרנט משולבות. ל- DGW יש יותר מ-15 שנות ניסיון במתן שירותי תכנות מקצועיים."
        />
        <meta
          property="twitter:image"
          content="https://dgw.co.il/_next/image?url=%2Flogo3.png&w=256&q=75"
        />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <main>
        <div className={styles.container}>
          <ContainerCom>
            <div className={styles.homeWelcome} style={{ zIndex: 1 }}>
              <div className={styles.homeWelcome_text}>
                <div
                  className={`${styles.homeWelcome_top} lg:text-5xl text-3xl`}
                >
                  מעוניינים ב
                </div>
                <div className={styles.homeWelcomeRealText}>
                  <div className={styles.homeWelcome_text_a}>{`</`}</div>
                  <div
                    className={`${styles.homeWelcome_text_b} text-3xl lg:text-5xl`}
                  >
                    <Typewriter
                      options={{
                        strings: [
                          "אתר לעסק?",
                          "אתר תדמיתי?",
                          "חנות דיגיטלית?",
                          "דף נחיתה?",
                          "מיתוג עסקי?",
                        ],
                        cursor: `<span style="color:#133140">|</span>`,
                        autoStart: true,
                        loop: true,
                      }}
                    />
                  </div>
                  <div className={styles.homeWelcome_text_c}>{`>`}</div>
                </div>
                <div
                  className={`${styles.homeWelcome_bottom} lg:text-5xl text-3xl`}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke-width="1.5"
                    stroke="currentColor"
                    className={`w-12 h-12 ${styles.bottomIcon}`}
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"
                    />
                  </svg>
                  הגעתם ליעד!
                </div>
              </div>
              <div className={styles.homeWelcome_img}>
                <Slide triggerOnce={true}>
                  {/* <Lottie
                  animationData={CodingLot}
                  loop={true}
                  rendererSettings={{ preserveAspectRatio: 'xMidYMid slice' }}
                /> */}
                  <Player autoplay loop src={CodingLot}></Player>
                  {/* <Image
                  alt='page cover'
                  src='/airplane-travel-svgrepo-com.svg'
                  width={400}
                  height={400}
                  objectFit='scale-down'
                /> */}
                  {/* <BuildingsFinal style={{ width: 400 }} /> */}
                </Slide>
              </div>
            </div>
          </ContainerCom>
        </div>
      </main>
      <section>
        <div className={styles.whatWeDoContainer} style={{ marginTop: "-8vw" }}>
          <div className={styles.whatWeDoContainer_in}>
            <div className={styles.waveContainer}>
              <svg
                width="100%"
                height="100%"
                style={{
                  display: "block",
                  marginBottom: "-12vw",
                }}
                id="svg"
                viewBox="0 0 1440 400"
                xmlns="http://www.w3.org/2000/svg"
                className="transition duration-300 ease-in-out delay-150"
              >
                <path
                  d="M 0,400 C 0,400 0,200 0,200 C 187.33333333333331,234.93333333333334 374.66666666666663,269.8666666666667 552,265 C 729.3333333333334,260.1333333333333 896.6666666666667,215.4666666666667 1043,198 C 1189.3333333333333,180.5333333333333 1314.6666666666665,190.26666666666665 1440,200 C 1440,200 1440,400 1440,400 Z"
                  stroke="none"
                  stroke-width="0"
                  fill="#ffffff"
                  fill-opacity="1"
                  className="transition-all duration-300 ease-in-out delay-150 path-0"
                  transform="rotate(-180 720 200)"
                ></path>
              </svg>

              <Slide>
                <div className={styles.container}>
                  <ContainerCom>
                    <div className={styles.whatWeDo}>
                      <div className={styles.sectionDarkTitle}>
                        <h1>מי אנחנו?</h1>
                      </div>
                      <div className={`${styles.whatWeDoItemsContainer}`}>
                        <div className="text-white lg:text-2xl md:text-s">
                          DGW – דיגיטל וויב הינה חברה המתמחה בעיצוב ופיתוח אתרי
                          אינטרנט ומערכות אינטרנט משולבות. ל- DGW יש יותר מ-15
                          שנות ניסיון במתן שירותי תכנות מקצועיים. סיימנו בהצלחה
                          מאות פרוייקטים בהיקף ומורכבות משתנים בתחומים שונים של
                          עסקים וטכנולוגיה.
                        </div>
                      </div>
                    </div>
                  </ContainerCom>
                </div>
              </Slide>

              <svg
                width="100%"
                height="100%"
                style={{ display: "block", marginTop: "-5vw" }}
                id="svg"
                viewBox="0 0 1440 400"
                xmlns="http://www.w3.org/2000/svg"
                className="transition duration-300 ease-in-out delay-150"
              >
                <path
                  d="M 0,400 C 0,400 0,133 0,133 C 72.06698564593302,158.78947368421052 144.13397129186603,184.57894736842104 253,171 C 361.86602870813397,157.42105263157896 507.53110047846894,104.47368421052633 603,103 C 698.4688995215311,101.52631578947367 743.7416267942584,151.52631578947367 829,160 C 914.2583732057416,168.47368421052633 1039.5023923444976,135.42105263157896 1148,124 C 1256.4976076555024,112.57894736842105 1348.248803827751,122.78947368421052 1440,133 C 1440,133 1440,400 1440,400 Z"
                  stroke="none"
                  stroke-width="0"
                  fill="#088bc9"
                  fill-opacity="0.53"
                  className="transition-all duration-300 ease-in-out delay-150 path-0"
                ></path>
                <path
                  d="M 0,400 C 0,400 0,266 0,266 C 102.99521531100478,274.3732057416268 205.99043062200957,282.7464114832536 307,270 C 408.00956937799043,257.2535885167464 507.03349282296654,223.38755980861248 608,225 C 708.9665071770335,226.61244019138752 811.8755980861245,263.70334928229664 906,276 C 1000.1244019138755,288.29665071770336 1085.4641148325359,275.79904306220095 1173,270 C 1260.5358851674641,264.20095693779905 1350.267942583732,265.1004784688995 1440,266 C 1440,266 1440,400 1440,400 Z"
                  stroke="none"
                  stroke-width="0"
                  fill="#088bc9"
                  fill-opacity="1"
                  className="transition-all duration-300 ease-in-out delay-150 path-1"
                ></path>
              </svg>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div
          className={styles.whatWeDoContainer}
          style={{ background: "#088bc9", marginTop: "-4vw" }}
        >
          <div className={styles.whatWeDoContainer_in}>
            <div className={styles.waveContainer}>
              <div className={styles.container}>
                <ContainerCom>
                  <div className={styles.whatWeDo}>
                    <div className={styles.sectionDarkTitle}>
                      <h2>מה אנחנו עושים?</h2>
                    </div>
                    <div className={`${styles.whatWeDoItemsContainer}`}>
                      <ul>
                        <li>
                          <div
                            className={`${styles.whatWeDoItem} transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-sky-400 duration-300`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke-width="1.5"
                              stroke="currentColor"
                              className="w-10 h-10"
                            >
                              <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418"
                              />
                            </svg>

                            <div className="lg:text-2xl md:text-s">
                              בניית אתרים
                            </div>
                          </div>
                        </li>
                        <li>
                          <div
                            className={`${styles.whatWeDoItem} transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-sky-400 duration-300`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke-width="1.5"
                              stroke="currentColor"
                              className="w-10 h-10"
                            >
                              <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M13.5 21v-7.5a.75.75 0 01.75-.75h3a.75.75 0 01.75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349m-16.5 11.65V9.35m0 0a3.001 3.001 0 003.75-.615A2.993 2.993 0 009.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 002.25 1.016c.896 0 1.7-.393 2.25-1.016a3.001 3.001 0 003.75.614m-16.5 0a3.004 3.004 0 01-.621-4.72L4.318 3.44A1.5 1.5 0 015.378 3h13.243a1.5 1.5 0 011.06.44l1.19 1.189a3 3 0 01-.621 4.72m-13.5 8.65h3.75a.75.75 0 00.75-.75V13.5a.75.75 0 00-.75-.75H6.75a.75.75 0 00-.75.75v3.75c0 .415.336.75.75.75z"
                              />
                            </svg>

                            <div className="lg:text-2xl md:text-s">
                              בניית חנות מסחרית
                            </div>
                          </div>
                        </li>
                        <li>
                          <div
                            className={`${styles.whatWeDoItem} transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-sky-400 duration-300`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke-width="1.5"
                              stroke="currentColor"
                              className="w-10 h-10"
                            >
                              <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M9.53 16.122a3 3 0 00-5.78 1.128 2.25 2.25 0 01-2.4 2.245 4.5 4.5 0 008.4-2.245c0-.399-.078-.78-.22-1.128zm0 0a15.998 15.998 0 003.388-1.62m-5.043-.025a15.994 15.994 0 011.622-3.395m3.42 3.42a15.995 15.995 0 004.764-4.648l3.876-5.814a1.151 1.151 0 00-1.597-1.597L14.146 6.32a15.996 15.996 0 00-4.649 4.763m3.42 3.42a6.776 6.776 0 00-3.42-3.42"
                              />
                            </svg>

                            <div className="lg:text-2xl md:text-s">
                              עיצוב אתרים
                            </div>
                          </div>
                        </li>
                        <li>
                          <div
                            className={`${styles.whatWeDoItem} transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-sky-400 duration-300`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 22 22"
                              stroke-width="1.5"
                              stroke="currentColor"
                              className="w-10 h-10"
                            >
                              <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M5.25 14.25h13.5m-13.5 0a3 3 0 01-3-3m3 3a3 3 0 100 6h13.5a3 3 0 100-6m-16.5-3a3 3 0 013-3h13.5a3 3 0 013 3m-19.5 0a4.5 4.5 0 01.9-2.7L5.737 5.1a3.375 3.375 0 012.7-1.35h7.126c1.062 0 2.062.5 2.7 1.35l2.587 3.45a4.5 4.5 0 01.9 2.7m0 0a3 3 0 01-3 3m0 3h.008v.008h-.008v-.008zm0-6h.008v.008h-.008v-.008zm-3 6h.008v.008h-.008v-.008zm0-6h.008v.008h-.008v-.008z"
                              />
                            </svg>
                            <div className="lg:text-2xl md:text-s">
                              אחסון אתרים
                            </div>
                          </div>
                        </li>
                        <li>
                          <div
                            className={`${styles.whatWeDoItem} transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-sky-400 duration-300`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke-width="1.5"
                              stroke="currentColor"
                              className="w-10 h-10"
                            >
                              <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z"
                              />
                            </svg>

                            <div className="lg:text-2xl md:text-s">
                              מיתוג עסקי
                            </div>
                          </div>
                        </li>
                        <li>
                          <div
                            className={`${styles.whatWeDoItem} transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-sky-400 duration-300`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke-width="1.5"
                              stroke="currentColor"
                              className="w-10 h-10"
                            >
                              <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M4.5 12.75l6 6 9-13.5"
                              />
                            </svg>

                            <div className="lg:text-2xl md:text-s">
                              אופטימיזציה SEO
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </ContainerCom>
              </div>
              <svg
                width="100%"
                height="100%"
                style={{ display: "block", marginTop: "-10vw" }}
                id="svg"
                viewBox="0 0 1440 400"
                xmlns="http://www.w3.org/2000/svg"
                className="transition duration-300 ease-in-out delay-150"
              >
                <path
                  d="M 0,400 C 0,400 0,200 0,200 C 266,232 532,264 772,264 C 1012,264 1226,232 1440,200 C 1440,200 1440,400 1440,400 Z"
                  stroke="none"
                  stroke-width="0"
                  fill="#03ddf8"
                  fill-opacity="1"
                  className="transition-all duration-300 ease-in-out delay-150 path-0"
                ></path>
              </svg>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div
          className={styles.whatWeDoContainer}
          style={{ background: "#03ddf8", marginTop: "-8vw" }}
        >
          <div className={styles.whatWeDoContainer_in}>
            <div className={`${styles.waveContainer}`}>
              <div className={styles.container}>
                <ContainerCom>
                  <div
                    className={`${styles.whatWeDo} ${styles.centerHomeContactContainer}`}
                  >
                    <div
                      className={styles.sectionDarkTitle}
                      style={{
                        display: "flex",
                        alignItems: "flex-start",
                        justifyContent: "flex-start",
                        color: "#133241",
                      }}
                    >
                      <h2>ההצלחה מתחילה מכאן</h2>
                    </div>
                    <div
                      className={`${styles.whatWeDoItemsContainer} ${styles.centerHomeContactContainer}`}
                    >
                      <div
                        className={`${styles.homeContactText} text-white lg:text-xl md:text-s`}
                      >
                        קבל ייעוץ חינם לכל השירותים שלנו וקבל את המענה ממומחים
                        <br />
                        שנותנים את המיטב עבורך.
                      </div>
                      <div className={`${styles.homeContactButton}`}>
                        <NavLink
                          href="/contact"
                          className=""
                          activeClassName=""
                        >
                          <button className="bg-sky-900 hover:bg-sky-500 text-white font-bold py-2 px-4 border-b-4 border-sky-500 hover:border-sky-900 rounded">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke-width="1.5"
                              stroke="currentColor"
                              className="w-6 h-6"
                              style={{
                                display: "inline-block",
                                marginInlineEnd: "5px",
                              }}
                            >
                              <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z"
                              />
                            </svg>
                            צרו קשר
                          </button>
                        </NavLink>
                      </div>
                    </div>
                  </div>
                </ContainerCom>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div
          className={styles.whatWeDoContainer}
          style={{ background: "#03ddf8" }}
        >
          <div className={styles.whatWeDoContainer_in}>
            <div className={`${styles.waveContainer}`}>
              <svg
                width="100%"
                height="100%"
                id="svg"
                viewBox="0 0 1440 210"
                style={{ display: "block", marginTop: "-9vw" }}
                xmlns="http://www.w3.org/2000/svg"
                className="transition duration-300 ease-in-out delay-150"
              >
                <path
                  d="M 0,400 C 0,400 0,200 0,200 C 208.5,184 417,168 657,168 C 897,168 1168.5,184 1440,200 C 1440,200 1440,400 1440,400 Z"
                  stroke="none"
                  stroke-width="0"
                  fill="#fff"
                  fill-opacity="1"
                  className="transition-all duration-300 ease-in-out delay-150 path-0"
                ></path>
              </svg>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default Home;
